"""
Export Service Module

Handles data export functionality including Excel and CSV generation.
"""

import os
import logging
from datetime import datetime
from typing import List, Dict, Any, TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from services.device_service import DeviceService
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from utils.device_filters import filter_devices_for_export
from services.risk_service import RiskService

logger = logging.getLogger(__name__)


class ExportService:
    """Service for handling device data exports"""
    
    def __init__(self, device_service: 'DeviceService'):
        """
        Initialize export service
        
        Args:
            device_service: DeviceService instance for data access
        """
        self.device_service = device_service
    
    def export_devices_to_excel(self, filter_args: Optional[Dict[str, Any]] = None, devices: Optional[List[Dict]] = None) -> str:
        """
        Export filtered devices to Excel file

        Args:
            filter_args: Dictionary of filter parameters (optional if devices provided)
            devices: Pre-filtered list of devices (optional)

        Returns:
            Path to generated Excel file

        Raises:
            Exception: If no data to export or export fails
        """
        logger.info(f"Starting Excel export with devices={devices is not None}, filter_args={filter_args}")

        if devices is None:
            # Get devices from service if not provided
            devices = self._get_devices_for_export()

        if filter_args:
            # Apply filters if provided
            filtered_devices = filter_devices_for_export(devices, filter_args)
        else:
            # Use provided devices directly
            filtered_devices = devices

        logger.info(f"After filtering: {len(filtered_devices)} devices to export")

        if not filtered_devices:
            raise Exception("No data to export")

        # Create Excel workbook
        filepath = self._create_excel_workbook(filtered_devices)

        logger.info(f"Exported {len(filtered_devices)} devices to Excel: {filepath}")
        return filepath
    
    def _get_devices_for_export(self) -> List[Dict]:
        """Get device data for export, handling both sample and API data"""
        config = self.device_service.config
        
        if config.USE_SAMPLE_DATA:
            return self.device_service._load_sample_data()
        else:
            # Production mode - use real Lookout API
            client = self.device_service.get_lookout_client()
            if client is None:
                raise Exception("API client not available")
            
            # Ensure authentication
            if not client.is_authenticated():
                client.authenticate()
            
            # Fetch devices from Lookout API
            logger.info("Fetching devices from Lookout API for export")
            raw_devices = client.get_devices(limit=1000)
            
            # Map devices to dashboard format using deprecated function for compatibility
            # TODO: Update to use enhanced_device_mapping once fully migrated
            from device_cache import enhanced_device_mapping
            devices = [enhanced_device_mapping(device) for device in raw_devices]
            logger.info(f"Successfully fetched and mapped {len(devices)} devices from Lookout API for export")
            
            return devices
    
    def _get_connection_status_info(self, days_since: int) -> Dict[str, str]:
        """Get connection status information for export"""
        if days_since == -1:
            return {'status': 'never_connected', 'label': 'Never Connected'}
        elif days_since <= 1:
            return {'status': 'connected', 'label': 'Connected'}
        elif days_since <= 7:
            return {'status': 'recent', 'label': 'Recent'}
        elif days_since <= 30:
            return {'status': 'stale', 'label': 'Stale'}
        elif days_since <= 90:
            return {'status': 'disconnected', 'label': 'Disconnected'}
        else:
            return {'status': 'very_stale', 'label': 'Very Stale'}

    def _create_excel_workbook(self, devices: List[Dict]) -> str:
        """
        Create Excel workbook with device data and reporting enhancements

        Args:
            devices: List of filtered device dictionaries

        Returns:
            Path to created Excel file
        """
        logger.info(f"Creating Excel workbook for {len(devices)} devices")

        wb = Workbook()
        
        # Create multiple sheets for better reporting
        self._create_summary_sheet(wb, devices)
        self._create_detailed_device_sheet(wb, devices)
        self._create_risk_analysis_sheet(wb, devices)
        self._create_compliance_sheet(wb, devices)
        
        # Remove default sheet if it exists
        if 'Sheet' in wb.sheetnames:
            del wb['Sheet']

        # Save to temporary file
        filename = f"device_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        filepath = os.path.join('/tmp', filename)
        wb.save(filepath)

        logger.info(f"Excel workbook saved to: {filepath}")
        return filepath
    
    def _create_summary_sheet(self, wb: Workbook, devices: List[Dict]):
        """Create executive summary sheet with key metrics"""
        ws = wb.create_sheet("Executive Summary", 0)
        
        # Title
        ws['A1'] = 'Fleet Management Report - Executive Summary'
        ws['A1'].font = Font(bold=True, size=16, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        ws.merge_cells('A1:D1')
        
        # Report metadata
        ws['A3'] = 'Report Generated:'
        ws['B3'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ws['A4'] = 'Total Devices:'
        ws['B4'] = len(devices)
        
        # Calculate statistics
        platform_counts = {}
        risk_counts = {}
        compliance_counts = {}
        connection_counts = {'connected': 0, 'recent': 0, 'stale': 0, 'disconnected': 0, 'very_stale': 0}
        mdm_counts = {}
        tenant_counts = {}
        total_issues = 0
        
        for device in devices:
            platform = device.get('platform', 'Unknown')
            risk = device.get('risk_level', 'Unknown')
            compliance = device.get('compliance_status', 'Unknown')
            
            platform_counts[platform] = platform_counts.get(platform, 0) + 1
            risk_counts[risk] = risk_counts.get(risk, 0) + 1
            compliance_counts[compliance] = compliance_counts.get(compliance, 0) + 1
            
            # Multi-tenant statistics
            mdm_provider = device.get('mdm_provider', 'N/A')
            tenant_name = device.get('tenant_name', 'N/A')
            mdm_counts[mdm_provider] = mdm_counts.get(mdm_provider, 0) + 1
            tenant_counts[tenant_name] = tenant_counts.get(tenant_name, 0) + 1
            
            # Calculate connection status
            try:
                last_checkin = datetime.fromisoformat(device['last_checkin'].replace('Z', '+00:00'))
                days_since = (datetime.now().replace(tzinfo=last_checkin.tzinfo) - last_checkin).days
            except (ValueError, KeyError):
                days_since = -1
            
            if days_since <= 1:
                connection_counts['connected'] += 1
            elif days_since <= 7:
                connection_counts['recent'] += 1
            elif days_since <= 30:
                connection_counts['stale'] += 1
            elif days_since <= 90:
                connection_counts['disconnected'] += 1
            else:
                connection_counts['very_stale'] += 1
            
            risk_analysis = RiskService.analyze_device_risk(device)
            total_issues += risk_analysis.get('total_issues', 0)
        
        # Platform breakdown
        row = 6
        ws[f'A{row}'] = 'Platform Distribution'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        ws[f'A{row}'] = 'Platform'
        ws[f'B{row}'] = 'Count'
        ws[f'C{row}'] = 'Percentage'
        for cell in [ws[f'A{row}'], ws[f'B{row}'], ws[f'C{row}']]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
        
        row += 1
        for platform, count in sorted(platform_counts.items()):
            ws[f'A{row}'] = platform
            ws[f'B{row}'] = count
            ws[f'C{row}'] = f"{(count/len(devices)*100):.1f}%"
            row += 1
        
        # Risk level breakdown
        row += 1
        ws[f'A{row}'] = 'Risk Level Distribution'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        ws[f'A{row}'] = 'Risk Level'
        ws[f'B{row}'] = 'Count'
        ws[f'C{row}'] = 'Percentage'
        for cell in [ws[f'A{row}'], ws[f'B{row}'], ws[f'C{row}']]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
        
        row += 1
        risk_order = ['Critical', 'High', 'Medium', 'Low', 'Secure']
        for risk_level in risk_order:
            count = risk_counts.get(risk_level, 0)
            if count > 0:
                ws[f'A{row}'] = risk_level
                ws[f'B{row}'] = count
                ws[f'C{row}'] = f"{(count/len(devices)*100):.1f}%"
                # Color code by risk
                if risk_level == 'Critical':
                    ws[f'A{row}'].fill = PatternFill(start_color="DC3545", end_color="DC3545", fill_type="solid")
                    ws[f'A{row}'].font = Font(color="FFFFFF", bold=True)
                elif risk_level == 'High':
                    ws[f'A{row}'].fill = PatternFill(start_color="FD7E14", end_color="FD7E14", fill_type="solid")
                elif risk_level == 'Medium':
                    ws[f'A{row}'].fill = PatternFill(start_color="FFC107", end_color="FFC107", fill_type="solid")
                elif risk_level == 'Low':
                    ws[f'A{row}'].fill = PatternFill(start_color="17A2B8", end_color="17A2B8", fill_type="solid")
                    ws[f'A{row}'].font = Font(color="FFFFFF")
                elif risk_level == 'Secure':
                    ws[f'A{row}'].fill = PatternFill(start_color="28A745", end_color="28A745", fill_type="solid")
                    ws[f'A{row}'].font = Font(color="FFFFFF")
                row += 1
        
        # Connection status
        row += 1
        ws[f'A{row}'] = 'Connection Status'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        ws[f'A{row}'] = 'Status'
        ws[f'B{row}'] = 'Count'
        ws[f'C{row}'] = 'Percentage'
        for cell in [ws[f'A{row}'], ws[f'B{row}'], ws[f'C{row}']]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
        
        row += 1
        for status, count in connection_counts.items():
            if count > 0:
                ws[f'A{row}'] = status.replace('_', ' ').title()
                ws[f'B{row}'] = count
                ws[f'C{row}'] = f"{(count/len(devices)*100):.1f}%"
                row += 1
        
        # Key metrics
        row += 1
        ws[f'A{row}'] = 'Key Metrics'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        ws[f'A{row}'] = 'Total Active Issues:'
        ws[f'B{row}'] = total_issues
        row += 1
        ws[f'A{row}'] = 'Average Issues per Device:'
        ws[f'B{row}'] = f"{(total_issues/len(devices)):.2f}"
        
        # Auto-adjust column widths
        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 15
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 15
    
    def _create_detailed_device_sheet(self, wb: Workbook, devices: List[Dict]):
        """Create detailed device listing sheet"""
        ws = wb.create_sheet("All Devices")

        # Define headers
        headers = [
            'Device Name', 'Device ID', 'User Email', 'Platform', 'Risk Level',
            'Active Issues', 'Last Check-in', 'Days Since Check-in', 'OS Version',
            'Security Patch', 'App Version', 'Compliance Status', 'Connection Status',
            'Device Group', 'MDM ID', 'Manufacturer', 'Model', 'Activation Status',
            'Threat Family Names', 'Threat Descriptions',
            'MDM Provider', 'MDM Identifier', 'Tenant ID', 'Tenant Name'
        ]

        # Style headers
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment

        # Add data with conditional formatting
        for row, device in enumerate(devices, 2):
            # Calculate days since checkin
            try:
                last_checkin = datetime.fromisoformat(device['last_checkin'].replace('Z', '+00:00'))
                days_since = (datetime.now().replace(tzinfo=last_checkin.tzinfo) - last_checkin).days
            except (ValueError, KeyError):
                days_since = -1

            risk_analysis = RiskService.analyze_device_risk(device)
            active_issues_count = risk_analysis.get('total_issues', 0)
            connection_info = self._get_connection_status_info(days_since)
            risk_level = device.get('risk_level', 'Unknown')

            # Populate row data
            ws.cell(row=row, column=1, value=device.get('device_name', 'Unknown'))
            ws.cell(row=row, column=2, value=device.get('device_id', ''))
            ws.cell(row=row, column=3, value=device.get('user_email', 'N/A'))
            ws.cell(row=row, column=4, value=device.get('platform', 'Unknown'))
            
            # Risk level with color coding
            risk_cell = ws.cell(row=row, column=5, value=risk_level)
            if risk_level == 'Critical':
                risk_cell.fill = PatternFill(start_color="DC3545", end_color="DC3545", fill_type="solid")
                risk_cell.font = Font(color="FFFFFF", bold=True)
            elif risk_level == 'High':
                risk_cell.fill = PatternFill(start_color="FD7E14", end_color="FD7E14", fill_type="solid")
            elif risk_level == 'Medium':
                risk_cell.fill = PatternFill(start_color="FFC107", end_color="FFC107", fill_type="solid")
            elif risk_level == 'Low':
                risk_cell.fill = PatternFill(start_color="17A2B8", end_color="17A2B8", fill_type="solid")
                risk_cell.font = Font(color="FFFFFF")
            elif risk_level == 'Secure':
                risk_cell.fill = PatternFill(start_color="28A745", end_color="28A745", fill_type="solid")
                risk_cell.font = Font(color="FFFFFF")
            
            ws.cell(row=row, column=6, value=active_issues_count)
            ws.cell(row=row, column=7, value=device.get('last_checkin', ''))
            ws.cell(row=row, column=8, value=days_since)
            ws.cell(row=row, column=9, value=device.get('os_version', 'Unknown'))
            ws.cell(row=row, column=10, value=device.get('security_patch_level', 'N/A'))
            ws.cell(row=row, column=11, value=device.get('app_version', 'Unknown'))
            ws.cell(row=row, column=12, value=device.get('compliance_status', 'Unknown'))
            ws.cell(row=row, column=13, value=connection_info['label'])
            ws.cell(row=row, column=14, value=device.get('device_group_name', 'N/A'))
            ws.cell(row=row, column=15, value=device.get('mdm_id', 'N/A'))
            ws.cell(row=row, column=16, value=device.get('manufacturer', 'N/A'))
            ws.cell(row=row, column=17, value=device.get('model', 'N/A'))
            ws.cell(row=row, column=18, value=device.get('activation_status', 'Unknown'))
            ws.cell(row=row, column=19, value=', '.join(device.get('threat_family_names', [])))
            ws.cell(row=row, column=20, value=', '.join(device.get('threat_descriptions', [])))
            
            # MDM information from Lookout API
            ws.cell(row=row, column=21, value=device.get('mdm_connector_id', 'N/A'))
            ws.cell(row=row, column=22, value=device.get('mdm_connector_uuid', 'N/A'))
            ws.cell(row=row, column=23, value=device.get('external_id', 'N/A'))
            
            # Multi-tenant fields
            ws.cell(row=row, column=24, value=device.get('mdm_provider', 'N/A'))
            ws.cell(row=row, column=25, value=device.get('mdm_identifier', 'N/A'))
            ws.cell(row=row, column=26, value=device.get('tenant_id', 'N/A'))
            ws.cell(row=row, column=27, value=device.get('tenant_name', 'N/A'))

        # Freeze panes for easier navigation
        ws.freeze_panes = 'A2'
        
        # Enable auto-filter
        ws.auto_filter.ref = f"A1:{ws.cell(row=1, column=len(headers)).column_letter}1"
        
        # Auto-adjust column widths (sample first 100 rows for performance)
        for col_idx, column in enumerate(ws.iter_cols(min_col=1, max_col=len(headers)), 1):
            max_length = len(str(headers[col_idx-1]))
            for cell in list(column)[1:min(101, len(devices)+1)]:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column[0].column_letter].width = adjusted_width
    
    def _create_risk_analysis_sheet(self, wb: Workbook, devices: List[Dict]):
        """Create risk analysis sheet with devices grouped by issues"""
        ws = wb.create_sheet("Risk Analysis")
        
        # Title
        ws['A1'] = 'Risk Analysis - Devices with Active Issues'
        ws['A1'].font = Font(bold=True, size=14, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="DC3545", end_color="DC3545", fill_type="solid")
        ws.merge_cells('A1:F1')
        
        row = 3
        devices_with_issues = []
        
        for device in devices:
            risk_analysis = RiskService.analyze_device_risk(device)
            if risk_analysis.get('total_issues', 0) > 0:
                devices_with_issues.append({
                    'device': device,
                    'analysis': risk_analysis
                })
        
        ws[f'A{row}'] = f'Devices with Issues: {len(devices_with_issues)} of {len(devices)}'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 2
        
        # Headers
        headers = ['Device Name', 'User Email', 'Risk Level', 'Total Issues', 'Issue Categories', 'Recommendations']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=row, column=col, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        
        row += 1
        
        # Sort by total issues (descending)
        devices_with_issues.sort(key=lambda x: x['analysis']['total_issues'], reverse=True)
        
        for item in devices_with_issues:
            device = item['device']
            analysis = item['analysis']
            
            ws.cell(row=row, column=1, value=device.get('device_name', 'Unknown'))
            ws.cell(row=row, column=2, value=device.get('user_email', 'N/A'))
            ws.cell(row=row, column=3, value=device.get('risk_level', 'Unknown'))
            ws.cell(row=row, column=4, value=analysis['total_issues'])
            
            # Issue categories
            categories = ', '.join(set([f['category'] for f in analysis.get('risk_factors', [])]))
            ws.cell(row=row, column=5, value=categories)
            
            # Recommendations (first 3)
            recommendations = '; '.join(analysis.get('recommendations', [])[:3])
            ws.cell(row=row, column=6, value=recommendations)
            
            row += 1
        
        # Auto-adjust column widths
        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 30
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 12
        ws.column_dimensions['E'].width = 30
        ws.column_dimensions['F'].width = 50
        
        # Freeze panes
        ws.freeze_panes = 'A6'
    
    def _create_compliance_sheet(self, wb: Workbook, devices: List[Dict]):
        """Create compliance tracking sheet"""
        ws = wb.create_sheet("Compliance Status")
        
        # Title
        ws['A1'] = 'Compliance Status Report'
        ws['A1'].font = Font(bold=True, size=14, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        ws.merge_cells('A1:E1')
        
        row = 3
        
        # Group by compliance status
        compliance_groups = {}
        for device in devices:
            status = device.get('compliance_status', 'Unknown')
            if status not in compliance_groups:
                compliance_groups[status] = []
            compliance_groups[status].append(device)
        
        # Summary
        ws[f'A{row}'] = 'Compliance Summary'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        
        for status, device_list in sorted(compliance_groups.items()):
            ws[f'A{row}'] = status
            ws[f'B{row}'] = len(device_list)
            ws[f'C{row}'] = f"{(len(device_list)/len(devices)*100):.1f}%"
            row += 1
        
        row += 1
        
        # Detailed listing
        ws[f'A{row}'] = 'Device Details'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        
        headers = ['Device Name', 'User Email', 'Platform', 'Compliance Status', 'Protection Status', 'Activation Status']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=row, column=col, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        
        row += 1
        
        for device in sorted(devices, key=lambda d: d.get('compliance_status', 'Unknown')):
            ws.cell(row=row, column=1, value=device.get('device_name', 'Unknown'))
            ws.cell(row=row, column=2, value=device.get('user_email', 'N/A'))
            ws.cell(row=row, column=3, value=device.get('platform', 'Unknown'))
            ws.cell(row=row, column=4, value=device.get('compliance_status', 'Unknown'))
            ws.cell(row=row, column=5, value=device.get('protection_status', 'Unknown'))
            ws.cell(row=row, column=6, value=device.get('activation_status', 'Unknown'))
            row += 1
        
        # Auto-adjust column widths
        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 30
        ws.column_dimensions['C'].width = 12
        ws.column_dimensions['D'].width = 20
        ws.column_dimensions['E'].width = 20
        ws.column_dimensions['F'].width = 20
        
        # Freeze panes
        ws.freeze_panes = 'A9'
    
    def create_csv_export(self, devices: List[Dict]) -> str:
        """
        Create CSV export of device data
        
        Args:
            devices: List of device dictionaries
            
        Returns:
            CSV content as string
        """
        headers = [
            'Device Name', 'User Email', 'Platform', 'Risk Level',
            'Active Issues', 'Last Check-in', 'OS Version', 'Compliance Status',
            'Device Group', 'MDM ID', 'Connection Status', 'Threat Family Names', 'Threat Descriptions'
        ]
        
        rows = []
        for device in devices:
            # Calculate active issues for CSV
            risk_analysis = RiskService.analyze_device_risk(device)
            active_issues_count = risk_analysis.get('total_issues', 0)
            
            # Get connection status info
            days_since = device.get('days_since_checkin', -1)
            connection_info = self._get_connection_status_info(days_since)

            row = [
                device.get('device_name', ''),
                device.get('user_email', ''),
                device.get('platform', ''),
                device.get('risk_level', ''),
                str(active_issues_count),
                device.get('last_checkin', ''),
                device.get('os_version', ''),
                device.get('compliance_status', ''),
                device.get('device_group_name', 'N/A'),
                device.get('mdm_id', 'N/A'),
                connection_info['label'],
                ', '.join(device.get('threat_family_names', [])),
                ', '.join(device.get('threat_descriptions', []))
            ]
            rows.append(row)
        
        # Create CSV content
        csv_rows = [headers] + rows
        csv_content = '\n'.join([
            ','.join([f'"{str(field).replace(chr(34), chr(34)+chr(34))}"' for field in row])
            for row in csv_rows
        ])
        
        return csv_content
    
    def export_cve_report_to_excel(self, cve_report: Dict[str, Any]) -> str:
        """
        Export CVE vulnerability report to Excel
        
        Args:
            cve_report: CVE report dictionary from CVEService
            
        Returns:
            Path to created Excel file
        """
        logger.info("Creating CVE vulnerability Excel report")
        
        wb = Workbook()
        
        # Create sheets
        self._create_cve_summary_sheet(wb, cve_report)
        self._create_cve_details_sheet(wb, cve_report)
        self._create_top_cves_sheet(wb, cve_report)
        
        # Remove default sheet
        if 'Sheet' in wb.sheetnames:
            del wb['Sheet']
        
        # Save file
        filename = f"cve_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        filepath = os.path.join('/tmp', filename)
        wb.save(filepath)
        
        logger.info(f"CVE report saved to: {filepath}")
        return filepath
    
    def _create_cve_summary_sheet(self, wb: Workbook, report: Dict[str, Any]):
        """Create CVE summary sheet"""
        ws = wb.create_sheet("CVE Summary", 0)
        
        # Title
        ws['A1'] = 'CVE Vulnerability Report - Summary'
        ws['A1'].font = Font(bold=True, size=16, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="DC3545", end_color="DC3545", fill_type="solid")
        ws.merge_cells('A1:D1')
        
        summary = report.get('summary', {})
        
        # Key metrics
        row = 3
        ws[f'A{row}'] = 'Report Generated:'
        ws[f'B{row}'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        row += 1
        ws[f'A{row}'] = 'Total Devices Scanned:'
        ws[f'B{row}'] = summary.get('total_devices', 0)
        row += 1
        ws[f'A{row}'] = 'Devices with Vulnerabilities:'
        ws[f'B{row}'] = summary.get('devices_with_vulnerabilities', 0)
        row += 1
        ws[f'A{row}'] = 'Vulnerability Percentage:'
        ws[f'B{row}'] = f"{summary.get('vulnerability_percentage', 0)}%"
        row += 1
        ws[f'A{row}'] = 'Total Unique CVEs Found:'
        ws[f'B{row}'] = summary.get('total_cves_found', 0)
        
        # Severity breakdown
        row += 2
        ws[f'A{row}'] = 'Severity Breakdown'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        
        ws[f'A{row}'] = 'Severity Level'
        ws[f'B{row}'] = 'CVE Count'
        for cell in [ws[f'A{row}'], ws[f'B{row}']]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
        row += 1
        
        severity_breakdown = summary.get('severity_breakdown', {})
        for severity in ['Critical', 'High', 'Medium', 'Low']:
            count = severity_breakdown.get(severity, 0)
            if count > 0:
                ws[f'A{row}'] = severity
                ws[f'B{row}'] = count
                
                # Color code by severity
                if severity == 'Critical':
                    ws[f'A{row}'].fill = PatternFill(start_color="DC3545", end_color="DC3545", fill_type="solid")
                    ws[f'A{row}'].font = Font(color="FFFFFF", bold=True)
                elif severity == 'High':
                    ws[f'A{row}'].fill = PatternFill(start_color="FD7E14", end_color="FD7E14", fill_type="solid")
                elif severity == 'Medium':
                    ws[f'A{row}'].fill = PatternFill(start_color="FFC107", end_color="FFC107", fill_type="solid")
                elif severity == 'Low':
                    ws[f'A{row}'].fill = PatternFill(start_color="17A2B8", end_color="17A2B8", fill_type="solid")
                    ws[f'A{row}'].font = Font(color="FFFFFF")
                row += 1
        
        # Scan metadata
        row += 1
        metadata = report.get('scan_metadata', {})
        ws[f'A{row}'] = 'Scan Details'
        ws[f'A{row}'].font = Font(bold=True, size=12)
        row += 1
        ws[f'A{row}'] = 'Android Patches Scanned:'
        ws[f'B{row}'] = metadata.get('android_patches_scanned', 0)
        row += 1
        ws[f'A{row}'] = 'iOS Versions Scanned:'
        ws[f'B{row}'] = metadata.get('ios_versions_scanned', 0)
        row += 1
        ws[f'A{row}'] = 'Minimum Severity Threshold:'
        ws[f'B{row}'] = metadata.get('minimum_severity', 7)
        
        # Column widths
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 20
    
    def _create_cve_details_sheet(self, wb: Workbook, report: Dict[str, Any]):
        """Create detailed CVE list sheet"""
        ws = wb.create_sheet("All CVEs")
        
        # Headers
        headers = ['CVE ID', 'Severity Score', 'Severity Level', 'Platform', 
                   'OS Version/Patch', 'Affected Devices', 'Description']
        
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
        
        # Data rows
        vulnerabilities = report.get('all_vulnerabilities', [])
        
        # Sort by severity (descending) then affected devices
        vulnerabilities.sort(key=lambda v: (v.get('severity', 0), v.get('affected_device_count', 0)), reverse=True)
        
        for row_idx, vuln in enumerate(vulnerabilities, 2):
            severity = vuln.get('severity', 0)
            severity_label = vuln.get('severity_label', 'Unknown')
            
            ws.cell(row=row_idx, column=1, value=vuln.get('cve', 'Unknown'))
            ws.cell(row=row_idx, column=2, value=severity)
            
            # Severity label with color
            severity_cell = ws.cell(row=row_idx, column=3, value=severity_label)
            if severity_label == 'Critical':
                severity_cell.fill = PatternFill(start_color="DC3545", end_color="DC3545", fill_type="solid")
                severity_cell.font = Font(color="FFFFFF", bold=True)
            elif severity_label == 'High':
                severity_cell.fill = PatternFill(start_color="FD7E14", end_color="FD7E14", fill_type="solid")
            elif severity_label == 'Medium':
                severity_cell.fill = PatternFill(start_color="FFC107", end_color="FFC107", fill_type="solid")
            
            ws.cell(row=row_idx, column=4, value=vuln.get('platform', 'Unknown'))
            ws.cell(row=row_idx, column=5, value=vuln.get('patch_level') or vuln.get('os_version', 'Unknown'))
            ws.cell(row=row_idx, column=6, value=vuln.get('affected_device_count', 0))
            ws.cell(row=row_idx, column=7, value=vuln.get('description', 'No description'))
        
        # Freeze panes and auto-filter
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = f"A1:G{len(vulnerabilities)+1}"
        
        # Column widths
        ws.column_dimensions['A'].width = 18
        ws.column_dimensions['B'].width = 12
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 10
        ws.column_dimensions['E'].width = 20
        ws.column_dimensions['F'].width = 15
        ws.column_dimensions['G'].width = 60
    
    def _create_top_cves_sheet(self, wb: Workbook, report: Dict[str, Any]):
        """Create top CVEs by affected devices sheet"""
        ws = wb.create_sheet("Top CVEs")
        
        # Title
        ws['A1'] = 'Top 10 CVEs by Affected Device Count'
        ws['A1'].font = Font(bold=True, size=14, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="DC3545", end_color="DC3545", fill_type="solid")
        ws.merge_cells('A1:C1')
        
        # Headers
        row = 3
        headers = ['Rank', 'CVE ID', 'Affected Devices']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=row, column=col, value=header)
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
        
        # Top CVEs
        row += 1
        top_cves = report.get('top_cves', [])[:10]
        
        for rank, cve_data in enumerate(top_cves, 1):
            ws.cell(row=row, column=1, value=rank)
            ws.cell(row=row, column=2, value=cve_data.get('cve', 'Unknown'))
            ws.cell(row=row, column=3, value=cve_data.get('affected_devices', 0))
            
            # Highlight top 3
            if rank <= 3:
                for col in range(1, 4):
                    ws.cell(row=row, column=col).fill = PatternFill(start_color="FFE6E6", end_color="FFE6E6", fill_type="solid")
            
            row += 1
        
        # Column widths
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 20
        ws.column_dimensions['C'].width = 18
    
    def get_export_stats(self, devices: List[Dict]) -> Dict[str, Any]:
        """
        Get statistics about devices being exported
        
        Args:
            devices: List of device dictionaries
            
        Returns:
            Dictionary with export statistics
        """
        total_devices = len(devices)
        
        # Count by risk level
        risk_counts = {}
        platform_counts = {}
        
        for device in devices:
            risk_level = device.get('risk_level', 'Unknown')
            platform = device.get('platform', 'Unknown')
            
            risk_counts[risk_level] = risk_counts.get(risk_level, 0) + 1
            platform_counts[platform] = platform_counts.get(platform, 0) + 1
        
        return {
            'total_devices': total_devices,
            'risk_level_distribution': risk_counts,
            'platform_distribution': platform_counts,
            'export_timestamp': datetime.now().isoformat()
        }