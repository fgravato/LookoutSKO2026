"""
Authentication package for the Lookout Dashboard.
"""

from auth.manager import AuthManager

__all__ = ['AuthManager']
